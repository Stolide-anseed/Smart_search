import re
from dataclasses import dataclass
from decimal import InvalidOperation
from pathlib import Path
from xml.etree.ElementTree import Element

from .catalog import Offer, catalog_elements, read_offer
from .query import number


_UPS_CATEGORY = "82080"
_BATTERY_CATEGORY = "82014"
_BATTERY_FIELD = "Совместимая батарея"
_APC_BATTERY_ARTICLE = re.compile(r"(?:APC)?(RBC[0-9]+)", re.IGNORECASE | re.ASCII)
_RECOMMENDATION_LIMIT = 2


@dataclass(frozen=True, slots=True)
class BatteryRecommendation:
    offer: Offer
    battery_reference: str
    available: bool
    has_price: bool


def _apc_battery_article(value: str) -> str:
    match = _APC_BATTERY_ARTICLE.fullmatch(value.strip())
    return match[1].upper() if match else ""


def supports_battery_recommendation(offer: Offer) -> bool:
    return offer.category_id == _UPS_CATEGORY and offer.vendor.casefold() == "apc"


def _battery_references(element: Element, offer: Offer) -> dict[str, str]:
    if not supports_battery_recommendation(offer):
        return {}
    references = {}
    for param in element.findall("param"):
        if param.get("name") != _BATTERY_FIELD:
            continue
        value = (param.text or "").strip()
        if article := _apc_battery_article(value):
            references[article] = value
    return references


def _has_price(offer: Offer) -> bool:
    try:
        price = number(offer.price)
    except InvalidOperation:
        return False
    return price.is_finite() and price > 0


def recommend_batteries(catalog_path: Path, selected: str) -> tuple[Offer, list[BatteryRecommendation]]:
    selected = selected.strip()
    if not selected:
        raise ValueError("Укажите ID предложения или его URL из фида.")

    source = None
    references: dict[str, str] = {}
    batteries: list[tuple[str, Offer, bool]] = []
    for element in catalog_elements(catalog_path):
        if element.tag != "offer":
            continue
        if selected in (element.get("id"), (element.findtext("url") or "").strip()):
            if source is not None:
                raise ValueError("Ссылке соответствуют несколько предложений. Укажите ID нужного предложения.")
            source = read_offer(element)
            references = _battery_references(element, source)
        if element.findtext("categoryId") != _BATTERY_CATEGORY:
            continue
        offer = read_offer(element)
        if offer.vendor.casefold() == "apc" and (article := _apc_battery_article(offer.vendor_code)):
            batteries.append((article, offer, element.get("available", "").casefold() == "true"))

    if source is None:
        raise ValueError(f"Предложение {selected} отсутствует в XML-каталоге.")

    matches = [
        (article, BatteryRecommendation(offer, references[article], available, _has_price(offer)))
        for article, offer, available in batteries
        if article in references and (not offer.group_id or offer.group_id != source.group_id)
    ]
    available_with_price = [(article, item) for article, item in matches if item.available and item.has_price]
    recommendations = []
    articles = set()
    groups = set()
    for article, item in available_with_price or matches:
        group_id = item.offer.group_id
        if article in articles or (group_id and group_id in groups):
            continue
        recommendations.append(item)
        articles.add(article)
        if group_id:
            groups.add(group_id)
        if len(recommendations) == _RECOMMENDATION_LIMIT:
            break
    return source, recommendations
