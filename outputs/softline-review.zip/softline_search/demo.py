import json
import sqlite3
from functools import lru_cache
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
from xml.etree.ElementTree import ParseError

from .catalog import Offer
from .index import SearchIndex, SearchMode
from .recommendation import recommend_batteries, supports_battery_recommendation


_ASSET_ROOT = Path(__file__).with_name("demo_web")
_ASSETS = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/app.css": ("app.css", "text/css; charset=utf-8"),
    "/app.js": ("app.js", "text/javascript; charset=utf-8"),
}


def _product(offer: Offer) -> dict:
    return {
        "id": offer.offer_id,
        "name": offer.name or offer.offer_id,
        "article": offer.vendor_code,
        "price": offer.price,
        "currency": offer.currency,
        "url": offer.url,
    }


def _search_products(index: SearchIndex, catalog: Path, mode: SearchMode, query: str) -> dict:
    result = index.search_checked(query, catalog, mode=mode)
    products = []
    for hit in result.hits + result.reserve:
        missing = result.unconfirmed.get(hit.offer.offer_id, ())
        products.append({
            **_product(hit.offer),
            "unconfirmed": missing,
            "can_recommend": not missing and supports_battery_recommendation(hit.offer),
        })
    return {
        "normalized": result.query.normalized,
        "conditions": list(dict.fromkeys(condition.source for condition in result.query.conditions)),
        "ambiguities": result.query.ambiguities,
        "products": products,
    }


def serve_demo(index: SearchIndex, catalog: Path, mode: SearchMode, port: int) -> None:
    if not catalog.is_file():
        raise FileNotFoundError(f"Каталог {catalog} не найден.")
    if not 0 <= port <= 65535:
        raise ValueError("Номер порта должен быть от 0 до 65535.")

    ups_offers = {
        offer.offer_id for offer in index.offers if supports_battery_recommendation(offer)
    }

    @lru_cache(maxsize=32)
    def recommendations(offer_id: str) -> dict:
        _, items = recommend_batteries(catalog, offer_id)
        return {"products": [
            {
                **_product(item.offer),
                "price": item.offer.price if item.has_price else "",
                "available": item.available,
                "reference": item.battery_reference,
            }
            for item in items
        ]}

    class DemoHandler(BaseHTTPRequestHandler):
        def _send(self, data: bytes, content_type: str, status: HTTPStatus) -> None:
            try:
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass

        def _json(self, data: dict, status: HTTPStatus = HTTPStatus.OK) -> None:
            self._send(json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8", status)

        def do_GET(self) -> None:
            try:
                url = urlsplit(self.path)
                if url.path in _ASSETS:
                    name, content_type = _ASSETS[url.path]
                    self._send((_ASSET_ROOT / name).read_bytes(), content_type, HTTPStatus.OK)
                elif url.path == "/api/search":
                    query = parse_qs(url.query).get("q", [""])[0].strip()
                    if query:
                        self._json(_search_products(index, catalog, mode, query))
                    else:
                        self._json({"error": "Введите поисковый запрос."}, HTTPStatus.BAD_REQUEST)
                elif url.path == "/api/recommend":
                    offer_id = parse_qs(url.query).get("offer_id", [""])[0]
                    if offer_id in ups_offers:
                        self._json(recommendations(offer_id))
                    else:
                        self._json({"error": "Подбор батареи доступен для ИБП APC из каталога."}, HTTPStatus.NOT_FOUND)
                else:
                    self.send_error(HTTPStatus.NOT_FOUND)
            except (OSError, ValueError, RuntimeError, sqlite3.Error, ParseError) as error:
                self._json({"error": str(error)}, HTTPStatus.INTERNAL_SERVER_ERROR)

    with HTTPServer(("127.0.0.1", port), DemoHandler) as server:
        print(f"Демо открыто на http://127.0.0.1:{server.server_port}/", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
