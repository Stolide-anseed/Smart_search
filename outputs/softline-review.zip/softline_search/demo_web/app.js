const byId = (id) => document.getElementById(id);
const form = byId("search-form");
const input = byId("query");
const submit = byId("search-submit");
const results = byId("results");
const searchStatus = byId("search-status");
const workspace = byId("workspace");
const queryDetails = byId("query-details");
const recommendationPanel = byId("recommendation-panel");
const recommendationSource = byId("recommendation-source");
const recommendationStatus = byId("recommendation-status");
const recommendations = byId("recommendations");
const formatNumber = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 6 });
const pluralRules = new Intl.PluralRules("ru-RU");

let searchRequest;
let recommendationRequest;

function element(tag, className, text = "") {
  const node = document.createElement(tag);
  node.className = className;
  node.textContent = text;
  return node;
}

function showStatus(node, text, error = false) {
  node.textContent = text;
  node.hidden = !text;
  node.dataset.error = String(error);
}

async function getJson(path, params, signal) {
  const response = await fetch(`${path}?${new URLSearchParams(params)}`, { signal });
  const payload = await response.json();
  if (!response.ok) {
    throw new Error(payload.error || "Попробуйте ещё раз.");
  }
  return payload;
}

function catalogLink(source) {
  let url;
  try {
    url = new URL(source);
  } catch {
    return null;
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") return null;
  const link = element("a", "offer-link", "Открыть в каталоге ↗");
  link.href = url.href;
  link.target = "_blank";
  link.rel = "noopener noreferrer";
  return link;
}

function productCard(product) {
  const card = element("article", "product-card");
  card.append(element("h3", "product-title", product.name));
  if (product.article) {
    card.append(element("p", "product-meta", `Артикул ${product.article}`));
  }

  const price = Number(product.price.replace(/\s/g, "").replace(",", "."));
  const currency = ["RUR", "RUB"].includes(product.currency) ? "₽" : product.currency;
  const knownPrice = Number.isFinite(price) && price > 0;
  card.append(element(
    "p", knownPrice ? "product-price" : "product-price price-unknown",
    knownPrice ? `${formatNumber.format(price)} ${currency}`.trim() : "Цена не указана в фиде",
  ));

  if (product.unconfirmed?.length) {
    card.append(element("p", "warning", `Не подтверждены условия — ${product.unconfirmed.join(", ")}`));
  }
  if (product.available === false) {
    card.append(element("p", "warning", "Недоступен по данным фида"));
  }
  if (product.reference) {
    card.append(element(
      "p", "status compatibility",
      `В характеристиках ИБП указана батарея ${product.reference}. Ей соответствует артикул ${product.article}.`,
    ));
  }

  const actions = element("div", "product-actions");
  const link = catalogLink(product.url);
  if (link) actions.append(link);
  if (product.can_recommend) {
    const button = element("button", "recommend-button", "Подобрать батарею");
    button.type = "button";
    button.setAttribute("aria-pressed", "false");
    button.addEventListener("click", () => loadRecommendations(product, button));
    actions.append(button);
  }
  if (actions.childElementCount) card.append(actions);
  return card;
}

function renderQueryDetails(data, query) {
  const changed = data.normalized !== query;
  byId("normalized-line").hidden = !changed;
  byId("normalized-query").textContent = data.normalized;
  byId("conditions-line").hidden = data.conditions.length === 0;
  byId("conditions").replaceChildren(...data.conditions.map((text) => element("li", "", text)));
  showStatus(byId("ambiguities"), data.ambiguities.join(" · "));
  queryDetails.hidden = !changed && !data.conditions.length && !data.ambiguities.length;
}

function renderResults(data) {
  const count = data.products.length;
  if (!count) {
    showStatus(searchStatus, "Подходящих товаров по этому запросу нет.");
    return;
  }

  const familyLabels = { one: "семейство", few: "семейства", many: "семейств" };
  byId("result-count").textContent = `${count} ${familyLabels[pluralRules.select(count)]}`;
  results.replaceChildren(...data.products.map(productCard));
  recommendationSource.hidden = true;
  recommendations.replaceChildren();
  showStatus(recommendationStatus, data.products.some((product) => product.can_recommend)
    ? "Нажмите «Подобрать батарею» на карточке ИБП."
    : "В демо подбор сопутствующих товаров доступен для ИБП APC.");
  workspace.hidden = false;
  showStatus(searchStatus, "");
}

async function loadSearch(value) {
  const query = value.trim();
  if (!query) {
    input.focus();
    showStatus(searchStatus, "Введите поисковый запрос.", true);
    return;
  }

  searchRequest?.abort();
  recommendationRequest?.abort();
  const request = new AbortController();
  searchRequest = request;
  input.value = query;
  form.setAttribute("aria-busy", "true");
  submit.textContent = "Ищем…";
  workspace.hidden = true;
  queryDetails.hidden = true;
  showStatus(searchStatus, "Ищем товары в каталоге. При первом запросе загружаются модель и характеристики.");

  try {
    const data = await getJson("/api/search", { q: query }, request.signal);
    if (request.signal.aborted) return;
    renderQueryDetails(data, query);
    renderResults(data);
  } catch (error) {
    if (!request.signal.aborted) showStatus(searchStatus, `Ошибка поиска. ${error.message}`, true);
  } finally {
    if (searchRequest === request) {
      searchRequest = null;
      form.removeAttribute("aria-busy");
      submit.textContent = "Найти";
    }
  }
}

async function loadRecommendations(product, button) {
  recommendationRequest?.abort();
  const request = new AbortController();
  recommendationRequest = request;
  for (const choice of results.querySelectorAll(".recommend-button")) {
    choice.setAttribute("aria-pressed", String(choice === button));
  }
  recommendationSource.textContent = product.name;
  recommendationSource.hidden = false;
  recommendations.replaceChildren();
  showStatus(recommendationStatus, "Проверяем совместимость по каталогу…");
  if (matchMedia("(max-width: 49rem)").matches) {
    recommendationPanel.scrollIntoView({ block: "start" });
  }

  try {
    const data = await getJson("/api/recommend", { offer_id: product.id }, request.signal);
    if (request.signal.aborted) return;
    recommendations.replaceChildren(...data.products.map(productCard));
    showStatus(recommendationStatus, data.products.length ? "" : "Подтверждённая батарея в каталоге не найдена.");
  } catch (error) {
    if (!request.signal.aborted) showStatus(recommendationStatus, `Ошибка подбора. ${error.message}`, true);
  } finally {
    if (recommendationRequest === request) recommendationRequest = null;
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  loadSearch(input.value);
});

for (const button of document.querySelectorAll("[data-query]")) {
  button.addEventListener("click", () => loadSearch(button.dataset.query));
}
