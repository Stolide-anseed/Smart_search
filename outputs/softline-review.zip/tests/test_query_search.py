from contextlib import closing
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import patch
from xml.etree.ElementTree import Element, SubElement, tostring

import numpy as np
from openpyxl import Workbook

from softline_search.encoder import EMBEDDING_SIZE
from softline_search.evaluation import evaluate, metrics
from softline_search.index import SearchIndex, build_index


class QuerySearchTests(TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        temporary = TemporaryDirectory()
        cls.addClassCleanup(temporary.cleanup)
        root = Path(temporary.name)
        cls.catalog = root / "catalog.xml"
        cls.index_path = root / "index.sqlite3"

        data = Element("yml_catalog")
        shop = SubElement(data, "shop")
        categories = SubElement(shop, "categories")
        for category, label in (
            ("ram", "Оперативная память"), ("laptop", "Ноутбуки"),
            ("other", "Оптические приводы"), ("shredder", "Шредеры"),
            ("office", "Офисные пакеты программ Microsoft Office"), ("monitor", "Мониторы"),
        ):
            SubElement(categories, "category", id=category).text = label
        offers = SubElement(shop, "offers")

        def add(offer_id, name, category, price, vendor="Example", attrs=(), description="", group="", code=""):
            offer = SubElement(offers, "offer", id=offer_id, available="true", group_id=group)
            for tag, value in (
                ("name", name), ("categoryId", category), ("price", price), ("vendor", vendor),
                ("currencyId", "RUR"), ("description", description), ("vendorCode", code),
            ):
                SubElement(offer, tag).text = value
            for key, value in attrs:
                SubElement(offer, "param", name=key).text = value

        laptop_memory = (("Ёмкость одного модуля", "8"), ("Назначение памяти", "для ноутбука"))
        add("ddr4", "Оперативная память DDR4 8 ГБ", "ram", "8000", attrs=(*laptop_memory, ("Тип памяти", "DDR4")))
        add("unknown", "Оперативная память для ноутбука 8 ГБ", "ram", "7500", attrs=laptop_memory)
        add("ddr3", "Оперативная память DDR3L 8 ГБ", "ram", "6500", attrs=(*laptop_memory, ("Тип памяти", "DDR3L")))
        add("memory16", "Оперативная память DDR4 16GB (1Gb*8)", "ram", "9500", attrs=(("Назначение памяти", "для ноутбука"),))
        add("notebook", "Ноутбук ASUS 16 ГБ", "laptop", "60000", vendor="ASUS")
        add("drive", "Привод ASUS", "other", "4000", vendor="ASUS", description="Ноутбук ASUS")
        add("office12", "Microsoft Office 2024 на 12 ПК, бессрочная", "office", "18000", vendor="Microsoft")
        add("office1", "Microsoft Office 2024 на 1 ПК, бессрочная", "office", "4000", vendor="Microsoft")
        add("office_subscription", "Microsoft Office 2024 на 20 ПК, подписка", "office", "5000", vendor="Microsoft")
        add("office_unknown", "Microsoft Office 2024 Standard, бессрочная", "office", "9000", vendor="Microsoft")
        add("shredder", "Шредер Example", "shredder", "13000")
        add("m1", "Монитор Example A1", "monitor", "9000", group="m1")
        add("m1_variant", "Монитор Example A1, RGB", "monitor", "11000", group="m1")
        add("m2_white", "Монитор Example B2", "monitor", "9000", code="B2/WHITE")
        add("m2_black", "Монитор Example B2", "monitor", "10000", code="B2/BLACK")
        add("m3", "Монитор Example C3", "monitor", "15000", code="C3")
        add("m3_duplicate", "Монитор C3 Example", "monitor", "16000", code="c3")
        add("m4", "Монитор Example D4", "monitor", "15000", code="D4")
        add("m5", "Монитор Example E5", "monitor", "17000", code="E5")
        add("m1_reserve", "Монитор Example A1, датчик", "monitor", "0", group="m1")
        for code in ("F6", "G7", "H8"):
            add(code, f"Монитор Example {code}", "monitor", "0", code=code)
        cls.catalog.write_bytes(tostring(data, encoding="utf-8"))

        vectors = np.full((len(offers), EMBEDDING_SIZE), 1 / 32, dtype="<f2")
        with patch("softline_search.index._catalog_embeddings", return_value=vectors):
            build_index(cls.catalog, cls.index_path, progress=lambda _: None)

    def test_layout_is_corrected_using_catalog_words(self) -> None:
        with closing(SearchIndex(self.index_path)) as index:
            parsed = index.parse_query("ihtlths", self.catalog)
            self.assertEqual(parsed.normalized, "шредеры")
            self.assertEqual(parsed.changes[0].kind, "раскладка")

    def test_budget_and_product_type_apply_to_direct_and_reserve_results(self) -> None:
        with closing(SearchIndex(self.index_path)) as index:
            results = index.search_checked("ноутбук асус до полтинника", self.catalog, mode="bm25")
            self.assertEqual(results.query.search_text, "ноутбук ASUS")
            self.assertEqual(results.hits, [])
            self.assertEqual(results.reserve, [])

    def test_known_conflict_is_excluded_and_unknown_goes_to_reserve(self) -> None:
        with closing(SearchIndex(self.index_path)) as index:
            result = index.search_checked("память для ноута ддр4 на восьмерку", self.catalog, mode="bm25")
            self.assertEqual([hit.offer.offer_id for hit in result.hits], ["ddr4"])
            self.assertEqual([hit.offer.offer_id for hit in result.reserve], ["unknown"])
            self.assertEqual(result.unconfirmed, {"unknown": ("DDR4",)})

    def test_license_count_is_a_minimum_and_subscription_is_excluded(self) -> None:
        with closing(SearchIndex(self.index_path)) as index:
            result = index.search_checked("Microsoft Office 2024 на 10 ПК без подписки", self.catalog, mode="bm25")
            self.assertEqual([hit.offer.offer_id for hit in result.hits], ["office12"])
            self.assertEqual([hit.offer.offer_id for hit in result.reserve], ["office_unknown"])

    def test_currency_is_not_confused_with_rubles_and_power_is_not_a_price(self) -> None:
        with closing(SearchIndex(self.index_path)) as index:
            parsed = index.parse_query("ноутбук ASUS до 1000 $", self.catalog)
            self.assertIn("price_usd", {condition.field for condition in parsed.conditions})
            result = index.search_checked("ноутбук ASUS до 1000 $", self.catalog, mode="bm25")
            self.assertEqual(result.hits, [])
            self.assertEqual([hit.offer.offer_id for hit in result.reserve], ["notebook"])
            power = index.parse_query("блок питания до 1200 Вт", self.catalog)
            self.assertEqual({condition.field for condition in power.conditions}, {"product_type", "power_w"})

    def test_checked_search_selects_four_families_and_deduplicates_articles(self) -> None:
        with closing(SearchIndex(self.index_path)) as index:
            offers = {offer.offer_id: offer for offer in index.offers}
            self.assertEqual(index.family_key(offers["m1"]), index.family_key(offers["m1_variant"]))
            self.assertEqual(index.family_key(offers["m2_white"]), index.family_key(offers["m2_black"]))
            self.assertEqual(index.family_key(offers["m3"]), index.family_key(offers["m3_duplicate"]))
            result = index.search_checked("монитор Example до 20 тыс. ₽", self.catalog, mode="bm25")
            self.assertEqual(len(result.hits), 4)
            self.assertEqual(len({index.family_key(hit.offer) for hit in result.hits}), 4)
            self.assertEqual(result.reserve, [])

    def test_reserve_fills_only_free_family_slots(self) -> None:
        with closing(SearchIndex(self.index_path)) as index:
            result = index.search_checked("монитор Example до 10 тыс. ₽", self.catalog, mode="bm25")
            self.assertEqual(len(result.hits), 2)
            self.assertEqual(len(result.reserve), 2)
            self.assertEqual(len({index.family_key(hit.offer) for hit in result.hits + result.reserve}), 4)
            self.assertNotIn("m1_reserve", result.unconfirmed)

    def test_evaluation_matches_a_suitable_variant_of_the_target_family(self) -> None:
        path = self.catalog.with_name("family_eval.xlsx")
        workbook = Workbook()
        workbook.active.append(["query", "target_url", "target_type", "target_id"])
        workbook.active.append(["монитор Example до 10 тыс. ₽", "https://example.test/m1", "offer", "m1_variant"])
        workbook.save(path)
        workbook.close()
        with closing(SearchIndex(self.index_path)) as index:
            rank = [(row, 1.0) for row, offer in enumerate(index.offers) if offer.offer_id == "m1"]
            with patch.object(index, "_rankings", return_value=(rank, rank)):
                rows = evaluate(index, path, catalog_path=self.catalog)
            scores = metrics(rows)["hybrid"]
            self.assertEqual(scores["HitRate@4"], 1)
            self.assertEqual(scores["Recall@4"], 1)
